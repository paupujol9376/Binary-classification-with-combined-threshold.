Este archivo ha sido creado el 04-09-2025 por Ramon Canal. 

INFORMACIÓN GENERAL
------------------

1. Título del conjunto de datos:  
	
    RISC-V Hardware Attack traces on On-Chip Hardware Performance Counters (HARPY-V Dataset)

2. Autoría:
	
    Nombre: Ramon Canal Corretger
    Institución: Universitat Politècnica de Catalunya, Departamento de Arquitectura de Computadores
    Correo electrónico: ramon.canal@upc.edu
    ORCID: https://orcid.org/0000-0003-4542-204X

    Nombre: Beatriz Otero Calviño
    Institución: Universitat Politècnica de Catalunya, Departamento de Arquitectura de Computadores
    Correo electrónico: beatriz.otero@upc.edu
    ORCID: https://orcid.org/0000-0002-9194-559X

    Nombre: Albert Pou Freixas
    Institución: Universitat Politècnica de Catalunya
    Correo electrónico: albert.pou@upc.edu

DESCRIPCIÓN
----------

1. Idioma del conjunto de datos: 

    Inglés

2. Resumen:

Conjunto de datos que contiene la monitorización de varios contadores de hardware (HPC) asociados a la prueba de concepto de 16 ataques de canales laterales (access-retired, evict-reload, fence-flush, flush-fault, flush-fault-ret, flush-flush, flush-reload, ghostwrite, iflush-reload, interrupt-timing, page-walk, spectre-rsb, spectre-v1, spectre-v2, timer-drift, tlb-evict); algunos tienen éxito y otros no, modificados para que el ataque se produzca más veces, junto con los datos obtenidos para 16 programas benignos/conjuntos de referencia (bitcoin, bubble-sort, bzip2, coremark, dhrystone, ffmpeg, mandelbrot, matrix, mybench, polybench, sha256sum, sieve, speedtest, stream, stress_c, stress_m). Todos los programas se ejecutan en una arquitectura RISC-V, concretamente el procesador Xuantie C910, con arquitectura RV64GCV.

La selección de los ataques de hardware utilizados para recopilar los datos se realizó analizando las características de la computadora, así como las mitigaciones disponibles, para determinar si la máquina era vulnerable a cada uno de ellos. Llegando a la conclusión de que todos los ataques tenían éxito, excepto evict-reload, flush-fault, flush-flush, spectre-v1, tlb-evict; los cuales fallaban en algunas de sus iteraciones. Se decidió incluir estos ataques para considerar todas las posibles estrategias maliciosas disponibles al entrenar al agente.

La selección de los programas benignos se basó principalmente en conjuntos de referencia que ofrecían un comportamiento de ejecución fiable y reproducible, permitiendo así una comparación eficaz con las cargas. Se hizo una selección de diferentes conjuntos de referencia con enfoques variados para garantizar una cobertura óptima del conjunto de datos.

Finalmente, se recogieron los datos de todos los contadores del procesador Xuantie C910 disponibles uno a uno y después se unieron en un único dataset para cada programa para realizar el análisis. La columna de tiempo es aproximada y no se utiliza para entrenar al agente.

3. Palabras clave:

Hardware. Ciberseguridad. Aprendizaje automático. Ataque de canal lateral. Spectre. Contadores de rendimiento. RISC-V.

4. Fecha de recogida de los datos (fecha única o rango de fechas): 

[22-30]-07-2025

5. Fecha de publicación de los datos: 

18-9-2025

6. Financiación recibida:

    Organismo financiador: Ministerio de Ciencia e Innovación 
    Código del proyecto: PID2021-124463OB-IOO

    Organismo financiador: Ministerio de Ciencia e Innovación 
    Código del proyecto: EQC2024-008344-P

    Organismo financiador: Generalitat de Catalunya 
    Código del proyecto: 2021-SGR-00326

    Organismo financiador: HORIZON-EU VITAMIN-V project
    Código del proyecto: Grant No. 101093062

7. Localización/es geográfica/s de los datos:

41.38879, 2.15899, Barcelona, España

INFORMACIÓN PARA EL ACCESO
------------------------

1. Licencia Creative Commons del conjunto de datos:

CC0 

2. DOI del conjunto de datos: 10.34810/data2538

3. Publicación relacionada:
[Citación bibliográfica, en el estilo estándar de su disciplina, de la publicación relacionada con el conjunto de datos, con el DOI incluido.]

VERSIÓN Y ORIGEN
---------------

1. Fecha de la última modificación: 

31-07-2025

2. ¿Son datos derivados de otra fuente?: 

Sí. Para la obtención de los datos, ha sido necesaria la identificación y adquisición de los códigos binarios de los programas (benignos y ataques) seleccionados. A continuación, se define para cada caso la fuente de donde se han obtenido los códigos.

Códigos malignos:
Codis malignes:
1) Access Retired, Github: The CISPA Helmholtz Center for Information Security (CISPA), access-retired, https://github.com/cispa/Security-RISC.
2) Evict+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), evict_reload_histogram (hist-u74), https://github.com/cispa/Security-RISC.
3) Fence+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), fence-flush, https://github.com/cispa/Security-RISC.
4) Flush+Fault, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault, https://github.com/cispa/Security-RISC.
5) Flush+Fault-ret, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault (flush-ret), https://github.com/cispa/Security-RISC.
6) Flush+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_flush_histogram, https://github.com/cispa/Security-RISC.
7) Flush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_reload_histogram, https://github.com/cispa/Security-RISC.
8) Ghostwrite, Github: The CISPA Helmholtz Center for Information Security (CISPA), GhostWrite, https://github.com/cispa/GhostWrite.
9) iFlush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), iflush_reload_histogram, https://github.com/cispa/Security-RISC.
10) Interrupt Timing, Github: The CISPA Helmholtz Center for Information Security (CISPA), interrupt-timing, https://github.com/cispa/Security-RISC.
11) Page Walk, Github: The CISPA Helmholtz Center for Information Security (CISPA), page-walk, https://github.com/cispa/Security-RISC.
12) Spectre RSB, Github: Codi de "A Study of MCU-level Attacks and Defenses on Power Distribution Fusion Terminals", spectre-RSB, https://github.com/zznjupt/Spectre-RISCV
13) Spectre v1, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre-v1, https://github.com/cispa/Security-RISC.
14) Spectre v2, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre, https://github.com/cispa/Security-RISC.
15) Timer Drift, Github: The CISPA Helmholtz Center for Information Security (CISPA), timer-drift, https://github.com/cispa/Security-RISC.
16) TLB eviction, Github: The CISPA Helmholtz Center for Information Security (CISPA), tlb_evict_histogram, https://github.com/cispa/Security-RISC.

Codigos benignos:
1) Bitcoin, Bitcoin Core v29.0, test_bitcoin, https://bitcoincore.org.
2) Bubble sort, codi propi.
3) bzip2 UNIX Tool, https://sourceware.org/bzip2.
4) CoreMark Benchmark, Github: https://github.com/eembc/coremark.
5) Dhrystone v2.1 Benchmark, https://www.netlib.org/benchmark/dhry-c.
6) ffmpeg, UNIX Package: https://ffmpeg.org.
7) Mandelbrot, mandelbrot.c, https://people.sc.fsu.edu/~jburkardt/c_src/mandelbrot/mandelbrot.html.
8) Matrix Multiplier: codi de HARPY. (?)
9) MiBench v1.0 Bitcount, University of Michigan, automotive/bitcount, https://vhosts.eecs.umich.edu/mibench.
10) PolyBench v4.2, datamining/correlation, https://sourceforge.net/projects/polybench/files.
11) sha256sum, Linux user command.
12) Sieve of Erathostenes, codi propi.
13) SpeedTest, Linux speedtest package, https://www.speedtest.net/apps/cli.
14) STREAM GitHub: John D. McCalpin, stream, https://www.cs.virginia.edu/stream/.
15) stress -c UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.
16) stress -m UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.

INFORMACIÓ METODOLÓGICA
-----------------------

Hay algunos pasos previos que deben realizarse para ejecutar correctamente todos los programas:

a. Extensión de la duración de los ataques:
Dado que la duración de los ataques es insuficiente, se ha introducido un bucle en el cuerpo de la función main del código para repetir el ataque muchas veces. También se ha deshabilitado la parte del código encargada de generar y escribir el resultado o el histograma.

b. Habilitación de eventos de rendimiento:
Por defecto, y por motivos de seguridad, la mayoría de los contadores de rendimiento están desactivados —ni siquiera aparecen al ejecutar la lista de rendimiento— y esto se controla mediante un archivo del sistema llamado perf_event_paranoid, ubicado en la carpeta /proc/sys/kernel/ de Linux. Hay cuatro niveles de seguridad disponibles (-1, 0, 1, 2), y configurar el archivo en 0 será suficiente para recopilar los datos necesarios.

c. Vaciado de las memorias caché:
Después de cada ejecución del programa, se vacían las memorias caché para evitar que afecten el comportamiento de la siguiente ejecución del mismo programa. Para ello, se ejecuta el siguiente comando antes de cada ejecución: sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"

1. Descripción de los métodos utilizados para recopilar y generar los datos:

Para generar el conjunto de datos, es necesario recopilar datos individuales para cada uno de los programas, tanto benignos como maliciosos. Para ello se utilizará la herramienta de estadísticas de rendimiento perf stat. Esta herramienta de línea de comandos acepta, entre otros parámetros, los diferentes HPC que se registrarán, conocidos como eventos (con la bandera -e seguida de r0xx, donde xx es el número hexadecimal del evento hardware que se desea monitorizar). Cabe destacar que, debido a la diferencia entre los nombres estándar de los eventos y lo que realmente registra perf, es preferible seguir las indicaciones del fabricante del hardware.

Otros parámetros relevantes incluyen:

La CPU a monitorizar (-C)
Un posible retardo antes de comenzar el registro (en milisegundos, con la bandera -D)
El intervalo para imprimir muestras (en milisegundos, con el indicador -I)
Además, perf dispone del indicador -x, que puede ir seguido de una cadena. Esto hará que la salida se muestre en un formato "similar a una tabla", utilizando el carácter , para generar un archivo CSV.

Los datos de los 20 contadores disponibles se recopilan uno por uno, ejecutando repetidamente el programa.

Finalmente, se utiliza una herramienta de temporización para limitar la ejecución de cada programa a 30–40 segundos, ya que algunos ataques y conjuntos de referencia pueden ejecutarse indefinidamente si no se detienen. Con una frecuencia de muestreo de 10 ms, se garantizan 2.000 muestras por ejecución. La mayoría de los ataques, aunque se ejecuten repetidamente, finalizan de forma natural en menos de 40 segundos. Posteriormente se eliminarán algunos registros de los programas para tener el mismo número de muestras entre benignos y maliciosos.

2. Métodos de procesamiento de los datos:

El procesamiento posterior se realizó utilizando la herramienta awk en un script de Bash, mediante el cual se unieron los datos de diferentes contadores en un único archivo. El resultado final consta de 21 columnas, que representan la marca de tiempo en el momento de ejecución de la muestra para cada uno de los valores de los contadores monitorizados.

3. Software o instrumentos necesarios para interpretar los datos:

Cualquier editor de texto (formato abierto) o Microsoft Excel (formato .csv)

4. Condiciones ambientales o experimentales:

Los códigos se ejecutaron en el procesador Xuantie C910 con arquitectura RISC-V.

5. Procedimientos seguidos para asegurar la calidad de los datos:

Eliminación de ruido en las muestras
Normalización de los datos
Balanceo de las muestras recopiladas para evitar overfitting en los modelos


ESTRUCTURA DE LOS ARCHIVOS
--------------------------

Explique las convenciones empleadas para nombrar los archivos, si procede:

<nombre_programa>-all_perf_events.csv

Lista de archivos:

Nombre archivo: bitcoin-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar un código que ejecuta los tests unitarios del software Bitcoin Core.

Nombre archivo: bubble-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar un código que crea iterativamente vectores con elementos aleatorios y los ordena con el algoritmo bubble-sort.

Nombre archivo: bzip2-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa bzip2. Este programa es un compresor de datos sin pérdidas de alta calidad, que también se puede utilizar como benchmark para ofrecer cargas tanto computacionales como de memoria. Para garantizar la replicabilidad del programa, el archivo comprimido será siempre el mismo, y será una imagen ISO de FreeBSD, tal como se utiliza en el sitio web OpenBenchmarking.org para evaluar el rendimiento de bzip2.

Nombre archivo: coremark-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa CoreMark, un benchmark diseñado para probar las características del procesador.

Nombre archivo: dhrystone-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Dhrystone, un benchmark diseñado para probar las características del procesador.

Nombre archivo: ffmpeg-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa ffmpeg. Ffmpeg es una herramienta multipropósito para audio y vídeo, que también se puede utilizar como benchmark y como ejemplo de carga de trabajo mixta común en un ordenador. En este ejemplo, ffmpeg se utilizará para descomprimir Big Buck Bunny (https://peach.blender.org/
), una gran animación creada con Blender y ampliamente utilizada para pruebas de vídeo.

Nombre archivo: mandelbrot-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar un código que genera el fractal mandelbrot de forma secuencial.

Nombre archivo: matrix-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar un código que multiplica grandes cantidades de números enteros para poner a prueba las capacidades computacionales de la CPU.

Nombre archivo: mybench-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa MiBench, un benchmark diseñado específicamente para el entorno automotriz. La prueba realiza un algoritmo de recuento de bits que somete la CPU a una carga significativa.

Nombre archivo: polybench-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Polybench, un benchmark diseñado para probar las características del procesador ejecutando varios cálculos numéricos.

Nombre archivo: sha256sum-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el comando sha256sum. Este programa crea un resumen de mensaje de un archivo. Para garantizar la replicabilidad del programa, el archivo comprimido será siempre el mismo, y será una imagen ISO de FreeBSD, en concreto la que se puede descargar de http://ftp-archive.freebsd.org/pub/FreeBSD-Archive/old-releases/amd64/amd64/ISO-IMAGES/13.0/FreeBSD-13.0-RELEASE-amd64-memstick.img

Nombre archivo: sieve-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar un código que crea la criba de Eratóstenes con una gran cantidad de números.

Nombre archivo: speedtest-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa SpeedTest, un benchmark diseñado para medir la velocidad de carga y descarga de la conexión a Internet.

Nombre archivo: stream-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa STREAM. Este programa es un benchmark diseñado para medir el ancho de banda de la memoria. En este caso, se utiliza exclusivamente por su efecto en el estrés de la unidad de memoria. El código fuente está disponible en el sitio web oficial de STREAM.

Nombre archivo: stress_c-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa basado en la herramienta stress de Debian con la opción -c. Este programa somete la unidad de cálculo de la CPU a una prueba de esfuerzo mediante el cálculo repetido de raíces cuadradas de números aleatorios.

Nombre archivo: stress_m-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa basado en la herramienta stress de Debian con la opción -m. El parámetro -m pone a prueba la unidad de memoria ejecutando repetidamente las funciones malloc() y free().

Nombre archivo: access-retired-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados después de ejecutar el programa Access Retired. Un ataque que monitoriza las instrucciones retiradas para detectar si un archivo está presente en un directorio que no admite listado. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: evict-reload-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Evict+Reload. Un ataque que detecta si una dirección de memoria está en la caché por el tiempo de acceso a esta tras desalojar los datos. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: fence-flush-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Fence+Flush. Un ataque que detecta si una dirección de memoria está en la caché por las diferencias de tiempo al vaciar la caché de instrucciones. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: flush-fault-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Flush+Fault. Un ataque que detecta si una dirección de memoria está en la caché según la latencia de una excepción al saltar a una instrucción del código de la víctima. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: flush-fault-ret-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Flush+Fault+ret. Un ataque que detecta si una dirección de memoria está en la caché según la latencia de una excepción al saltar a una instrucción de retorno del código de la víctima. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: flush-flush-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Flush+Flush. Un ataque que detecta si la víctima ha escrito en una dirección de memoria por las diferencias de tiempo al vaciar la caché de instrucciones y acceder a ella de nuevo. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: flush-reload-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Flush+Reload. Un ataque que detecta si una dirección de memoria está en la caché por las diferencias de tiempo al vaciar la caché y acceder a ella posteriormente. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: ghostwrite-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa GhostWrite. Un ataque que resuelve la dirección física de una dirección virtual y escribe directamente en ella. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: iflush-reload-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa iFlush+Reload. Variante del ataque Flush+Reload para la caché de instrucciones. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: interrupt-timing-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Interrupt Timing. Un ataque que detecta las interrupciones de la víctima por las diferencias de tiempo que provocan en la ejecución de código. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: page-walk-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Page Walk. Un ataque que detecta el recorrido de la tabla de páginas contando instrucciones retiradas o por diferencias de tiempo. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: spectre-rsb-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Spectre RSB. Una variación de Spectre que se aprovecha de la especulación sobre la pila de direcciones de retorno (Return Stack Buffer).

Nombre archivo: spectre-v1-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Spectre versión 1. El código de la prueba de concepto (PoC) correspondiente a la versión 1 de Spectre se ha extraído del repositorio de Github de CISPA.

Nombre archivo: spectre-v2-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Spectre versión 2. El código de la prueba de concepto (PoC) correspondiente a la versión 2 de Spectre se ha extraído del repositorio de Github.

Nombre archivo: timer-drift-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa Timer Drift. Un ataque que monitoriza las instrucciones retiradas para detectar actividad remota. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

Nombre archivo: tlb-evict-all_perf_events.csv
Descripción: Estos datos contienen los valores de los contadores de hardware analizados tras ejecutar el programa TLB eviction. Un ataque que busca las diferencias de tiempo cuando la dirección de la víctima se encuentra en la TLB y cuando se desaloja la TLB y la dirección ya no está presente. El código de la prueba de concepto (PoC) se ha extraído del repositorio de Github de CISPA.

3. Relación entre los archivos:

Cada archivo corresponde a uno de los 32 programas ejecutados para generar los valores de los contadores de hardware analizados. Cada archivo está identificado por el nombre del programa asociado a su ejecución.

4. Formato de los archivos:

Todos los archivos contienen las mismas variables, por este motivo solo se describen para el primer archivo.


INFORMACIÓN ESPECÍFICA PARA DATOS TABULADOS
-------------------------------------------

1. Nombre del archivo: bitcoin-all_perf_events.csv
2. Número de filas y columnas: 2677 filas y 21 columnas
3. Lista de variables:

Nombre de la variable: Time
Descripción: Tiempo de muestreo
Unidades de medida o etiquetas de valor: ms

Nombre de la variable: r002/Instructions retired counter
Descripción: Contador de hardware que mide el número de instrucciones ejecutadas.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r003/L1 ICache Access Counter
Descripción: Contador de hardware que mide el número de accesos a la caché de instrucciones.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r004/L1 ICache Miss Counter
Descripción: Contador de hardware que mide el número de veces que falla el acceso a la caché de instrucciones.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r005/I-UTLB Miss Counter
Descripción: Contador de hardware que mide el número de veces que falla el acceso al TLB de instrucciones gestionado por el usuario.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r006/D-UTLB Miss Counter
Descripción: Contador de hardware que mide el número de veces que falla el acceso al TLB de datos gestionado por el usuario.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r007/JTLB Miss Counter
Descripción: Contador de hardware que mide el número de veces que falla el acceso al Joint TLB.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r008/Conditional Branch Mispredict Counter
Descripción: Contador de hardware que mide el número de veces que hay un error de predicción en un salto condicional.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r009/Conditional Branch Instruction Counter
Descripción: Contador de hardware que mide el número de veces que se ejecuta un salto condicional.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00A/Indirect Branch Mispredict Counter
Descripción: Contador de hardware que mide el número de veces que hay un error de predicción en un salto indirecto (a través de registro).
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00B/Indirect Branch Instruction Counter
Descripción: Contador de hardware que mide el número de veces que se ejecuta un salto indirecto (a través de registro).
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00C/LSU Spec Fail Counter
Descripción: Contador de hardware que mide el número de veces que falla la unidad load-store. Por ejemplo, cuando se produce un load antes de que un store previo en la misma posición se haya podido efectuar.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00D/Store Instruction Retired Counter
Descripción: Contador de hardware que mide el número de instrucciones store ejecutadas.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00E/L1 DCache Read Access Counter
Descripción: Contador de hardware que mide el número de accesos de lectura a la caché de datos de primer nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r00F/L1 DCache Read Miss Counter
Descripción: Contador de hardware que mide el número de fallos en accesos de lectura a la caché de datos de primer nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r010/L1 DCache Write Access Counter
Descripción: Contador de hardware que mide el número de accesos de escritura a la caché de datos de primer nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r011/L1 DCache Write Miss Counter
Descripción: Contador de hardware que mide el número de fallos en accesos de escritura a la caché de datos de primer nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r012/L2 Cache Read Access Counter
Descripción: Contador de hardware que mide el número de accesos de lectura a la caché de segundo nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r013/L2 Cache Read Miss Counter
Descripción: Contador de hardware que mide el número de fallos en accesos de lectura a la caché de segundo nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r014/L2 Cache Write Access Counter
Descripción: Contador de hardware que mide el número de accesos de escritura a la caché de segundo nivel.
Unidades de medida o etiquetas de valor: Eventos.

Nombre de la variable: r015/L2 Cache Write Miss Counter
Descripción: Contador de hardware que mide el número de fallos en accesos de escritura a la caché de segundo nivel.
Unidades de medida o etiquetas de valor: Eventos.

1. Nombre del archivo: bubble-all_perf_events.csv
2. Número de filas y columnas: 2279 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: bzip2-all_perf_events.csv
2. Número de filas y columnas: 2282 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: coremark-all_perf_events.csv
2. Número de filas y columnas: 2291 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: dhrystone-all_perf_events.csv
2. Número de filas y columnas: 2287 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: ffmpeg-all_perf_events.csv
2. Número de filas y columnas: 2054 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: mandelbrot-all_perf_events.csv
2. Número de filas y columnas: 2280 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: matrix-all_perf_events.csv
2. Número de filas y columnas: 2258 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: mybench-all_perf_events.csv
2. Número de filas y columnas: 2271 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: polybench-all_perf_events.csv
2. Número de filas y columnas: 2278 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: sha256sum-all_perf_events.csv
2. Número de filas y columnas: 2399 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: sieve-all_perf_events.csv
2. Número de filas y columnas: 2164 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: speedtest-all_perf_events.csv
2. Número de filas y columnas: 2077 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: stream-all_perf_events.csv
2. Número de filas y columnas: 2300 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: stress_c-all_perf_events.csv
2. Número de filas y columnas: 2300 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: stress_m-all_perf_events.csv
2. Número de filas y columnas: 2231 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: access-retired-all_perf_events.csv
2. Número de filas y columnas: 2862 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: evict-reload-all_perf_events.csv
2. Número de filas y columnas: 2200 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: fence-flush-all_perf_events.csv
2. Número de filas y columnas: 2182 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: flush-fault-all_perf_events.csv
2. Número de filas y columnas: 2856 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: flush-fault-ret-all_perf_events.csv
2. Número de filas y columnas: 2854 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: flush-flush-all_perf_events.csv
2. Número de filas y columnas: 2213 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: flush-reload-all_perf_events.csv
2. Número de filas y columnas: 2279 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: ghostwrite-all_perf_events.csv
2. Número de filas y columnas: 2286 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: iflush-reload-all_perf_events.csv
2. Número de filas y columnas: 3070 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: interrupt-timing-all_perf_events.csv
2. Número de filas y columnas: 3022 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: page-walk-all_perf_events.csv
2. Número de filas y columnas: 3087 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: spectre-rsb-all_perf_events.csv
2. Número de filas y columnas: 3054 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: spectre-v1-all_perf_events.csv
2. Número de filas y columnas: 2285 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: spectre-v2-all_perf_events.csv
2. Número de filas y columnas: 3055 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: timer-drift-all_perf_events.csv
2. Número de filas y columnas: 3861 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.

1. Nombre del archivo: tlb-evict-all_perf_events.csv
2. Número de filas y columnas: 3012 filas y 21 columnas
3. Lista de Variables: Contiene las mismas variables que las explicadas para el primer archivo descrito.