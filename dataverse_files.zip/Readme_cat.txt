Aquest arxiu ha estat creat el 04-09-2025 per Ramon Canal. 

INFORMACICÓ GENERAL
------------------

1. Títol del conjunt de dades:  
	
	RISC-V Hardware Attack Detection using On-Chip Hardware Performance Counters Dataset

2. Autoria:
	
	Nom: Ramon Canal Corretger
	InstituciC3: Universitat Politècnica de Catalunya, Departament d'Arquitectura de Computadors
	Correu electrònic: ramon.canal@upc.edu
	ORCID: https://orcid.org/0000-0003-4542-204X

	Nom: Beatriz Otero Calviño
	Institució: Universitat Politècnica de Catalunya, Departament d'Arquitectura de Computadors
	Correu electrònic: beatriz.otero@upc.edu
	ORCID: https://orcid.org/0000-0002-9194-559X

	Nom: Albert Pou Freixas
	Institució: Universitat Politècnica de Catalunya
	Correu electrònic: albert.pou@upc.edu

DESCRIPCIÓ
----------

1. Idioma del conjunt de dades: 

	Anglès

2. Resum:

Conjunt de dades que conté la monitorització de diversos comptadors de maquinari (HPC) associats a la prova de concepte de 16 atacs de canals laterals (access-retired, evict-reload, fence-flush, flush-fault, flush-fault-ret, flush-flush, flush-reload, ghostwrite, iflush-reload, interrupt-timing, page-walk, spectre-rsb, spectre-v1, Spectre-v2, timer-drift, tlb-evict); alguns tenen èxit i d'altres no, modificats perqué l'atac es produeixi més vegades, juntament amb les dades obtingudes per a 16 programes benignes/conjunts de referència (bitcoin, bubble-sort, bzip2, coremark, dhrystone, ffmpeg, mandelbrot, matrix, mybench, polybench, sha256sum, sieve, speedtest, stream, stress_c, stress_m). Tots els programes s'executen en una arquitectura RISC-V, concretament el processador Xuantie C910, amb arquitectura RV64GCV.

La selecció dels atacs de maquinari utilitzats per recopilar les dades es va realitzar analitzant les característiques de la computadora, així com les mitigacions disponibles, per determinar si la màquina era vulnerable a cadascun d'ells. Arribant a la conclusió que tots els atacs tenien èxit, excepte evict-reload, flush-fault, flush-flush, spectre-v1, tlb-evict; els quals fallaven en algunes de les seves iteracions. Es va decidir incloure aquests atacs per considerar totes les possibles estratègies malignes disponibles a l'entrenar l'agent.

La selecció dels programes benignes es va basar principalment en conjunts de referència que oferien un comportament d'execució fiable i reproduible, permetent així una comparació eficaç amb les càrregues. Es va fer una selecció de diferents conjunts de referència amb enfocaments variats per garantir una cobertura òptima del conjunt de dades.

Finalment, es van recollir les dades de tots els comptadors del processador Xuantie C910 disponibles un a un i després es van ajuntar en un únic dataset per a cada programa per fer l'anàlisi. La columna de temps és aproximada i no s'utilitza per entrenar l'agent.

3. Paraules clau:

Hardware. Cybersecurity. Machine Learning. Side channel attack. Spectre. Performance counters. RISC-V.

4. Data de recollida de les dades (data única o rang de dates): 

[22-30]-07-2025

5. Data de publicació de les dades: 

18-9-2025

6. Finançament rebut:

	Organisme finançador: Ministerio de Ciencia e Innovación 
	Codi del projecte:PID2021-124463OB-IOO

	Organisme finançador: Ministerio de Ciencia e Innovación 
	Codi del projecte:EQC2024-008344-P

	Organisme finançador: Generalitat de Catalunya 
	Codi del projecte:2021-SGR-00326

	Organisme finançador: HORIZON-EU VITAMIN-V project
	Codi del projecte:Grant No. 101093062

7. Localització/ns geogràfica/ques de les dades:

41.38879, 2.15899, Barcelona, Spain

INFORMACIÓ PER A L'ACCÉS
------------------------

1. Llicència Creative Commons del conjunt de dades:

CC0 

2. DOI del conjunt de dades: 10.34810/data2538

3. Publicació relacionada:
[Citació bibliogràfica, en l'estil estàndard de la vostra disciplina, de la publicació relacionada amb el conjunt de dades, amb el DOI inclòs.]



VERSIÓ I ORIGEN
---------------

1. Data de la darrera modificació: 

31-07-2025

2. Són dades derivades d'una altra font?: 

Si. Per a l'obtenció de les dades, ha estat necessària la identificació i adquisició dels codis binaris dels programes (benignes i atacs) seleccionats. A continuació, es defineix per a cada cas la font d'on s'han obtingut els codis.

Codis malignes:
1) Access Retired, Github: The CISPA Helmholtz Center for Information Security (CISPA), access-retired, https://github.com/cispa/Security-RISC.
2) Evict+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), evict_reload_histogram (hist-u74), https://github.com/cispa/Security-RISC.
3) Fence+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), fence-flush, https://github.com/cispa/Security-RISC.
4) Flush+Fault, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault, https://github.com/cispa/Security-RISC.
5) Flush+Fault-ret, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault (flush-ret), https://github.com/cispa/Security-RISC.
6) Flush+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_flush_histogram, https://github.com/cispa/Security-RISC.
7) Flush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_reload_histogram, https://github.com/cispa/Security-RISC.
8) Ghostwrite, Github: The CISPA Helmholtz Center for Information Security (CISPA), GhostWrite, https://github.com/cispa/GhostWrite.
9) iFlush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), iflush_reload_histogram, https://github.com/cispa/Security-RISC.
10) Interrupt Timing, Github: The CISPA Helmholtz Center for Information Security (CISPA), interrupt-timing, https://github.com/cispa/Security-RISC.
11) Page Walk, Github: The CISPA Helmholtz Center for Information Security (CISPA), page-walk, https://github.com/cispa/Security-RISC.
12) Spectre RSB, Github: Codi de "A Study of MCU-level Attacks and Defenses on Power Distribution Fusion Terminals", spectre-RSB, https://github.com/zznjupt/Spectre-RISCV
13) Spectre v1, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre-v1, https://github.com/cispa/Security-RISC.
14) Spectre v2, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre, https://github.com/cispa/Security-RISC.
15) Timer Drift, Github: The CISPA Helmholtz Center for Information Security (CISPA), timer-drift, https://github.com/cispa/Security-RISC.
16) TLB eviction, Github: The CISPA Helmholtz Center for Information Security (CISPA), tlb_evict_histogram, https://github.com/cispa/Security-RISC.

(?) Codis benignes:
1) Bitcoin, Bitcoin Core v29.0, test_bitcoin, https://bitcoincore.org.
2) Bubble sort, codi propi.
3) bzip2 UNIX Tool, https://sourceware.org/bzip2.
4) CoreMark Benchmark, Github: https://github.com/eembc/coremark.
5) Dhrystone v2.1 Benchmark, https://www.netlib.org/benchmark/dhry-c.
6) ffmpeg, UNIX Package: https://ffmpeg.org.
7) Mandelbrot, mandelbrot.c, https://people.sc.fsu.edu/~jburkardt/c_src/mandelbrot/mandelbrot.html.
8) Matrix Multiplier: codi de HARPY. (?)
9) MiBench v1.0 Bitcount, University of Michigan, automotive/bitcount, https://vhosts.eecs.umich.edu/mibench.
10) PolyBench v4.2, datamining/correlation, https://sourceforge.net/projects/polybench/files.
11) sha256sum, Linux user command.
12) Sieve of Erathostenes, codi propi.
13) SpeedTest, Linux speedtest package, https://www.speedtest.net/apps/cli.
14) STREAM GitHub: John D. McCalpin, stream, https://www.cs.virginia.edu/stream/.
15) stress -c UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.
16) stress -m UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.


INFORMACIÓ METODOLÓGICA
-----------------------

Hi ha alguns passos previs que cal realitzar per tal d'executar tots els programes correctament:

a. Degut a què la duració dels atacs és insuficient, s'ha introduït un bucle al cos de la funció main del seu codi per repetir l'atac una gran quantitat de vegades. També es deshabilita la part del codi de generació i escriptura del resultat o l'histograma.

b. Habilitar esdeveniments de rendiment: Per defecte, i per motius de seguretat, la majoria dels comptadors de rendiment estan desactivats -ni tan sols apareixeran quan s'executi la llista de rendiment- i això es controla mitjançant un arxiu del sistema anomenat perf_event_paranoid, que es troba a la carpeta /proc/sys/kernel/ de Linux. Hi ha quatre nivells de seguretat disponibles (-1, 0, 1, 2) i la configuració de l'arxiu en 0 serà suficient per recopilar les dades necessàries.

c. Buidat de les memòries cau: Desprès de cada execució del programa, les memòries cau es buiden per evitar que afectin el comportament de la següent execució del mateix programa. Per fer-ho, s'executa la següent ordre abans de cada execució:
sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"

1. Descripció dels mètodes emprats per recollir i generar les dades: 

Per generar el conjunt de dades, és necessari recopilar dades individuals per a cadascun dels programes, tant benignes com maliciosos. Per això, s'utilitzarà  l'eina d'estadístiques de rendiment perf stat. Aquesta eina de línia de comandes accepta, entre altres paràmetres, els diferents HPC que es registraran, coneguts com a esdeveniments (amb la bandera -e seguida d'r0xx, on xx és el número d'esdeveniment hardware en hexadecimal que es vulgui monitoritzar). Cal fer notar que, per la diferència entre els noms dels esdeveniments estàndard i el que realment registra el perf, és preferible seguir les indicacions del fabricant del hardware. La CPU a monitoritzar (amb l'indicador -C); un possible retard abans de començar a registrar (en mil·lisegons, amb la bandera -D); i l'interval per imprimir mostres (en mil·lisegons, amb l'indicador -I).

A més, perf disposa de l'indicador -x, que pot anar seguit d'una cadena. Això farà que la sortida es mostri en un format "semblant a una taula", utilitzant el caràcter ',' per obtenir un fitxer CSV.

Es recullen les dades dels 20 comptadors disponibles un a un, executant repetidament el programa.

Finalment, s'utilitza l'eina de temporització per limitar l'execució de cada programa a 30-40 segons, ja que alguns atacs i conjunts de referència poden executar-se indefinidament si no es detenen. Amb una freqüècia de mostreig de 10 ms, es garanteixen 2000 mostres per a cada execució. La majoria d'atacs, tot i executar-se repetidament, acaben la seva execució de manera natural en menys de 40 segons. S'eliminaran posteriorment alguns registres dels programes per tal de tenir el mateix número de mostres entre benignes i malignes.

2. Mètodes de processament de les dades: 

El processament posterior es va realitzar utilitzant l'eina awk en un script de bash, mitjançant les quals vam unir les dades de diferents comptadors en un únic arxiu. El resultat final consta de 21 columnes, que representen la marca de temps en temps d'execució de la mostra per a cada un dels valors dels comptadors monitoritzats.

3. Programari o instruments necessaris per interpretar les dades:

Qualsevol editor de text (format obert) o Microsoft Excel (format .csv)

4. Condicions ambientals o experimentals:

Codis executats en el processador Xuantie C910 amb arquitectura RISC-V.

5. Procediments seguits per assegurar la qualitat de les dades:

Eliminació de soroll en les mostres.
Normalització de les dades.
Balanç de les mostres recopilades per no generar overfitting en els models.

ESTRUCTURA DELS ARXIUS
----------------------

1. Expliqueu les convencions emprades per anomenar els arxius, si s'escau:

<nom_programa>-all_perf_events.csv

2. Llista d'arxius:

	Nom arxiu: bitcoin-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar un codi que executa els tests unitaris del programari Bitcoin Core.

	Nom arxiu: bubble-all_perf_events.csv
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar un codi que crea iterativament vectors amb elements aleatoris i els ordena amb l'algorisme bubble-sort.	 

        Nom arxiu: bzip2-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa bzip2. Aquest programa és un compressor de dades sense pèrdues de alta qualitat, que també es pot utilitzar com a benchmark per oferir càrregues tant computacionals com de memòria. Per garantir la replicabilitat del programa, el fitxer comprimit serà sempre el mateix, i serà una imatge ISO de FreeBSD, tal com s'utilitza al lloc web OpenBenchmarking.org per avaluar el rendiment de bzip2.

	Nom arxiu: coremark-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa CoreMark, un benchmark dissenyat per provar les característiques del processador.

	Nom arxiu: dhrystone-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa Dhrystone, un benchmark dissenyat per provar les característiques del processador.

 	Nom arxiu: ffmpeg-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa ffmpeg. Ffmpeg és una eina multipropòsit per àudio i vídeo, que també es pot utilitzar com a benchmark i com a exemple de càrrega de treball mixta comuna en un ordinador. En aquest exemple, ffmpeg s'utilitzarà per descomprimir Big Buck Bunny (https://peach.blender.org/), una gran animació creada amb Blender i àmpliament utilitzada per a proves de vídeo.

	Nom arxiu: mandelbrot-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar un codi que genera el fractal mandelbrot de forma seqüencial.

        Nom arxiu: matrix-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar un codi que multiplica grans quantitats de nombres enters per posar a prova les capacitats computacionals de la CPU.

	Nom arxiu: mybench-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa MiBench, un benchmark dissenyat específicament per a l'entorn automotriu. La prova realitza un algoritme de recompte de bits que sotmet la CPU a una càrrega significativa.

	Nom arxiu: polybench-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa Polybench, un benchmark dissenyat per provar les característiques del processador executant diversos càlculs numèrics.

        Nom arxiu: sha256sum-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar la comanda sha256sum. Aquest programa crea un resum de missatge d'un arxiu. Per garantir la replicabilitat del programa, el fitxer comprimit serà sempre el mateix, i serà una imatge ISO de FreeBSD, en concret la que es pot descarregar d'http://ftp-archive.freebsd.org/pub/FreeBSD-Archive/old-releases/amd64/amd64/ISO-IMAGES/13.0/FreeBSD-13.0-RELEASE-amd64-memstick.img.

	Nom arxiu: sieve-all_perf_events.csv
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar un codi que crea la criba d'Eratòstenes amb una gran quantitat de números.

	Nom arxiu: speedtest-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa SpeedTest, un benchmark dissenyat per mesurar la velocitat de càrrega i descàrrega de la connexió a Internet.
	 
        Nom arxiu: stream-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa STREAM. Aquest programa és un benchmark dissenyat per mesurar l'ample de banda de la memòria. En aquest cas, s'utilitza exclusivament pel seu efecte en l'estrès de la unitat de memòria. El codi font està disponible al lloc web oficial de STREAM.

        Nom arxiu: stress_c-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa basat en l'eina stress de Debian amb l'opció -c. Aquest programa sotmet la unitat de càlcul de la CPU a una prova d'esforç mitjaçant el càlcul repetit d'arrels quadrades de nombres aleatoris. 
	 
        Nom arxiu: stress_m-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa basat en l'eina stress de Debian amb l'opció -m. El paràmetre -m posa a prova la unitat de memòria executant repetidament les funcions malloc() i free().     
    
	Nom arxiu: access-retired-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Access Retired. Un atac que monitoritza les instruccions retirades per detectar si un arxiu és present a un directori que no admet llistat. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: evict-reload-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Evict+Reload. Un atac que detecta si una adreça de memòria és a la cache pel temps d'accés a aquesta després de desallotjar les dades. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: fence-flush-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Fence+Flush. Un atac que detecta si una adreça de memòria és a la cache per les diferències de temps al buidar la cache d'instruccions. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: flush-fault-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Flush+Fault. Un atac que detecta si una adreça de memòria és a la cache segons la latència d'una excepció al saltar a una instrucció del codi de la víctima. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: flush-fault-ret-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Flush+Fault+ret. Un atac que detecta si una adreça de memòria és a la cache segons la latència d'una excepció al saltar a una instrucció de retorn del codi de la víctima. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: flush-flush-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Flush+Flush. Un atac que detecta si la víctima ha escrit a una adreça de memòria per les diferències de temps al buidar la cache d'instruccions i accedir-hi de nou. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: flush-reload-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Flush+Reload. Un atac que detecta si una adreça de memòria és a la cache per les diferències de temps al buidar la cache i accedir-hi posteriorment. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: ghostwrite-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa GhostWrite. Un atac que resol la direcció física d'una adreça virtual i hi escriu directament. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: iflush-reload-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa iFlush+Reload. Variant de l'atac Flush+Reload per la cache d'instruccions. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: interrupt-timing-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Interrupt Timing. Un atac que detecta les interrupcions de la víctima per les diferències de temps que provoquen en l'execució de codi. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA. 	

	Nom arxiu: page-walk-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Page Walk. Un atac que detecta el recorregut de la taula de pàgines comptant instruccions retirades o per diferències de temps. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

      	Nom arxiu: spectre-rsb-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa Spectre RSB. Una variació de l'Spectre que s'aprofita de l'especulació sobre la pila d'adreces de retorn (Return Stack Buffer).

      	Nom arxiu: spectre-v1-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats desprès d'executar el programa Spectre versió 1. El codi de la prova de concepte (PoC) corresponent a la versió 1 de Spectre s'ha extret del repositori de Github de CISPA.

	Nom arxiu: spectre-v2-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Spectre versió 2. El codi de la prova de concepte (PoC) corresponent a la versió 2 de Spectre s'ha extret del repositori de Github.

	Nom arxiu: timer-drift-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa Timer Drift. Un atac que monitoritza les instruccions retirades per detectar activitat remota. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

	Nom arxiu: tlb-evict-all_perf_events.csv     
	Descripció: Aquestes dades contenen els valors dels comptadors de maquinari analitzats després d'executar el programa TLB eviction. Un atac que busca les diferències de temps quan l'adreça de la víctima es troba a la TLB i quan es desallotja la TLB i l'adreça no hi és. El codi de la prova de concepte (PoC) s'ha extret del repositori de Github de CISPA.

3. Relació entre els arxius: 

Cada fitxer correspon a un dels 32 programes executats per generar els valors dels comptadors de maquinari analitzats. Cada fitxer està identificat pel nom del programa associat a la seva execució.

4. Format dels arxius:    

Tots els fitxers contenen les mateixes variables, per aquest motiu només s'hi descriuen al primer fitxer.

INFORMACIÓ ESPECÍFICA PER A DADES TABULADES 
-------------------------------------------

1. Nom de l'arxiu: bitcoin-all_perf_events.csv
2. Nombre de files i columnes: 2677 files i 21 columnes
3. Llista de Variables:

	Nom de la variable: Time
        Descripció: Temps de mostreig
	Unitats de mesura o etiquetes de valor: ms 

	Nom de la variable: r002/Instructions retired counter
        Descripció: Comptador de maquinari que mesura el nombre d'instruccions executades.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r003/L1 ICache Access Counter
        Descripció: Comptador de maquinari que mesura el nombre d'accessos a la cache d'instruccions.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r004/L1 ICache Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que falla l'accés a la cache d'instruccions.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	(??)Nom de la variable: r005/I-UTLB Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que falla l'accés a l'User-managed TLB d'instruccions.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	(??)Nom de la variable: r006/D-UTLB Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que falla l'accés a l'User-managed TLB de dades.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	(??)Nom de la variable: r007/JTLB Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que falla l'accés al Joint TLB.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r008/Conditional Branch Mispredict Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que hi ha un error de predicció d'un salt condicional.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r009/Conditional Branch Instruction Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que s'executa un salt condicional.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r00A/Indirect Branch Mispredict Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que hi ha un error de predicció d'un salt indirecte -a través de registre.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r00B/Indirect Branch Instruction Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que s'executa un salt indirecte -a través de registre.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	(??) Nom de la variable: r00C/LSU Spec Fail Counter
        Descripció: Comptador de maquinari que mesura el nombre de vegades que falla la unitat load-store. Per exemple, quan es produeix un load abans que un store previ a la mateixa posició s'hagi pogut efectuar.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r00D/Store Instruction Retired Counter
        Descripció: Comptador de maquinari que mesura el nombre d'instruccions store executades.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r00E/L1 DCache Read Access Counter
        Descripció: Comptador de maquinari que mesura el nombre d'accessos de lectura a la cache de dades de primer nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r00F/L1 DCache Read Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de fallades d'accessos de lectura a la cache de dades de primer nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r010/L1 DCache Write Access Counter
        Descripció: Comptador de maquinari que mesura el nombre d'accessos d'escriptura a la cache de dades de primer nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r011/L1 DCache Write Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de fallades d'accessos d'escriptura a la cache de dades de primer nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r012/L2 Cache Read Access Counter
        Descripció: Comptador de maquinari que mesura el nombre d'accessos de lectura a la cache de segon nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r013/L2 Cache Read Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de fallades d'accessos de lectura a la cache de segon nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r014/L2 Cache Write Access Counter
        Descripció: Comptador de maquinari que mesura el nombre d'accessos d'escriptura a la cache de segon nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

	Nom de la variable: r015/L2 Cache Write Miss Counter
        Descripció: Comptador de maquinari que mesura el nombre de fallades d'accessos d'escriptura a la cache de segon nivell.
	Unitats de mesura o etiquetes de valor: Esdeveniments.

1. Nom de l'arxiu: bubble-all_perf_events.csv
2. Nombre de files i columnes: 2279 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: bzip2-all_perf_events.csv
2. Nombre de files i columnes: 2282 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: coremark-all_perf_events.csv
2. Nombre de files i columnes: 2291 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: dhrystone-all_perf_events.csv
2. Nombre de files i columnes: 2287 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: ffmpeg-all_perf_events.csv
2. Nombre de files i columnes: 2054 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: mandelbrot-all_perf_events.csv
2. Nombre de files i columnes: 2280 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: matrix-all_perf_events.csv
2. Nombre de files i columnes: 2258 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: mybench-all_perf_events.csv
2. Nombre de files i columnes: 2271 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: polybench-all_perf_events.csv
2. Nombre de files i columnes: 2278 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: sha256sum-all_perf_events.csv
2. Nombre de files i columnes: 2399 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: sieve-all_perf_events.csv
2. Nombre de files i columnes: 2164 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: speedtest-all_perf_events.csv
2. Nombre de files i columnes: 2077 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: stream-all_perf_events.csv
2. Nombre de files i columnes: 2300 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: stress_c-all_perf_events.csv
2. Nombre de files i columnes: 2300 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: stress_m-all_perf_events.csv
2. Nombre de files i columnes: 2231 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: access-retired-all_perf_events.csv
2. Nombre de files i columnes: 2862 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: evict-reload-all_perf_events.csv
2. Nombre de files i columnes: 2200 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: fence-flush-all_perf_events.csv
2. Nombre de files i columnes: 2182 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: flush-fault-all_perf_events.csv
2. Nombre de files i columnes: 2856 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: flush-fault-ret-all_perf_events.csv
2. Nombre de files i columnes: 2854 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: flush-flush-all_perf_events.csv
2. Nombre de files i columnes: 2213 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: flush-reload-all_perf_events.csv
2. Nombre de files i columnes: 2279 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: ghostwrite-all_perf_events.csv
2. Nombre de files i columnes: 2286 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: iflush-reload-all_perf_events.csv
2. Nombre de files i columnes: 3070 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: interrupt-timing-all_perf_events.csv
2. Nombre de files i columnes: 3022 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: page-walk-all_perf_events.csv
2. Nombre de files i columnes: 3087 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: spectre-rsb-all_perf_events.csv
2. Nombre de files i columnes: 3054 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: spectre-v1-all_perf_events.csv
2. Nombre de files i columnes: 2285 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: spectre-v2-all_perf_events.csv
2. Nombre de files i columnes: 3055 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: timer-drift-all_perf_events.csv
2. Nombre de files i columnes: 3861 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.

1. Nom de l'arxiu: tlb-evict-all_perf_events.csv
2. Nombre de files i columnes: 3012 files i 21 columnes
3. Llista de Variables: Conté les mateixes variables que les explicades per al primer fitxer descrit.
