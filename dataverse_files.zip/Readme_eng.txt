This file was created on 04-9-2025 by Ramon Canal.

GENERAL INFORMATION
-------------------

1. Title of Dataset: 

	RISC-V Hardware Attack traces on On-Chip Hardware Performance Counters (HARPY-V Dataset)

2. Authorship: 

	Name: Albert Pou Freixas
	Institution: Universitat Politécnica de Catalunya
	Email: albert.pou@estudiantat.upc.edu
	
	Name: Beatriz Otero Calviño
	Institution: Universitat Politécnica de Catalunya, Departament d'Arquitectura de Computadors
	Email: beatriz.otero@upc.edu
	ORCID: https://orcid.org/0000-0002-9194-559X

	Name: Ramon Canal Corretger
	Institution: Universitat Politécnica de Catalunya, Departament d'Arquitectura de Computadors
	Email: ramon.canal@upc.edu
	ORCID: https://orcid.org/0000-0003-4542-204X

DESCRIPTION
-----------

1. Dataset language:

English


2. Abstract:
Dataset containing the monitoring of various hardware performance counters (HPCs) associated with the proof of concept for 16 side-channel attacks (access-retired, evict-reload, fence-flush, flush-fault, flush-fault-ret, flush-flush, flush-reload, ghostwrite, iflush-reload, interrupt-timing, page-walk, spectre-rsb, spectre-v1, spectre-v2, timer-drift, tlb-evict); some are successful and others are not, modified so that the attack occurs more frequently, along with the data obtained for 16 benign programs/reference sets (bitcoin, bubble-sort, bzip2, coremark, dhrystone, ffmpeg, mandelbrot, matrix, mybench, polybench, sha256sum, sieve, speedtest, stream, stress_c, stress_m). All programs are executed on a RISC-V architecture, specifically the Xuantie C910 processor, with RV64GCV architecture.

The selection of hardware attacks used to collect the data was carried out by analyzing the characteristics of the computer, as well as the available mitigations, to determine whether the machine was vulnerable to each of them. It was concluded that all attacks were successful except evict-reload, flush-fault, flush-flush, spectre-v1, and tlb-evict; which failed in some of their iterations. These attacks were included to consider all possible malicious strategies available when training the agent.

The selection of benign programs was mainly based on reference sets that offered reliable and reproducible execution behavior, thus allowing effective comparison with the attack workloads. A selection of different reference sets with varied approaches was made to ensure optimal coverage of the dataset.

Finally, data from all available counters on the Xuantie C910 processor were collected one by one and then merged into a single dataset for each program for analysis. The time column is approximate and is not used for training the agent.

3. Keywords:

Hardware. Cybersecurity. Machine Learning. Side-channel attack. Spectre. Performance counters. RISC-V.

4. Date of data collection (single date or date range):

[22–30]-07-2025

5. Date of dataset publication:

18-09-2025

6. Funding sources: 

	Funding agency: Ministerio de Ciencia e Innovación
	Project number: PID2021-124463OB-IOO

	Funding agency: Ministerio de Ciencia e Innovación
	Project number: EQC2024-008344-P

	Funding agency: Generalitat de Catalunya
	Project number: 2021-SGR-00326

	Funding agency: HORIZON-EU VITAMIN-V project
	Project number: Grant No. 101093062

7. Geographic location/s of data collection:

41.38879, 2.15899, Barcelona, Spain

ACCESS INFORMATION
------------------

1. Creative Commons License of the dataset:

CC0

2. Dataset DOI:10.34810/data2538

3. Related publication:

VERSIONING AND PROVENANCE
-------------------------

1. Last modification date:

2024-07-31

2. Was data derived from another source?:

Yes. For the data collection, it was necessary to identify and acquire the binary codes of the selected programs (benign and attacks). Below, the source from which the codes were obtained is defined for each case.

Malicious codes:
1) Access Retired, Github: The CISPA Helmholtz Center for Information Security (CISPA), access-retired, https://github.com/cispa/Security-RISC.
2) Evict+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), evict_reload_histogram (hist-u74), https://github.com/cispa/Security-RISC.
3) Fence+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), fence-flush, https://github.com/cispa/Security-RISC.
4) Flush+Fault, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault, https://github.com/cispa/Security-RISC.
5) Flush+Fault-ret, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush-fault (flush-ret), https://github.com/cispa/Security-RISC.
6) Flush+Flush, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_flush_histogram, https://github.com/cispa/Security-RISC.
7) Flush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), flush_reload_histogram, https://github.com/cispa/Security-RISC.
8) Ghostwrite, Github: The CISPA Helmholtz Center for Information Security (CISPA), GhostWrite, https://github.com/cispa/GhostWrite.
9) iFlush+Reload, Github: The CISPA Helmholtz Center for Information Security (CISPA), iflush_reload_histogram, https://github.com/cispa/Security-RISC.
10) Interrupt Timing, Github: The CISPA Helmholtz Center for Information Security (CISPA), interrupt-timing, https://github.com/cispa/Security-RISC.
11) Page Walk, Github: The CISPA Helmholtz Center for Information Security (CISPA), page-walk, https://github.com/cispa/Security-RISC.
12) Spectre RSB, Github: Codi de "A Study of MCU-level Attacks and Defenses on Power Distribution Fusion Terminals", spectre-RSB, https://github.com/zznjupt/Spectre-RISCV
13) Spectre v1, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre-v1, https://github.com/cispa/Security-RISC.
14) Spectre v2, Github: The CISPA Helmholtz Center for Information Security (CISPA), spectre, https://github.com/cispa/Security-RISC.
15) Timer Drift, Github: The CISPA Helmholtz Center for Information Security (CISPA), timer-drift, https://github.com/cispa/Security-RISC.
16) TLB eviction, Github: The CISPA Helmholtz Center for Information Security (CISPA), tlb_evict_histogram, https://github.com/cispa/Security-RISC.


Benign codes:
1) Bitcoin, Bitcoin Core v29.0, test_bitcoin, https://bitcoincore.org.
2) Bubble sort, codi propi.
3) bzip2 UNIX Tool, https://sourceware.org/bzip2.
4) CoreMark Benchmark, Github: https://github.com/eembc/coremark.
5) Dhrystone v2.1 Benchmark, https://www.netlib.org/benchmark/dhry-c.
6) ffmpeg, UNIX Package: https://ffmpeg.org.
7) Mandelbrot, mandelbrot.c, https://people.sc.fsu.edu/~jburkardt/c_src/mandelbrot/mandelbrot.html.
8) Matrix Multiplier: codi de HARPY. (?)
9) MiBench v1.0 Bitcount, University of Michigan, automotive/bitcount, https://vhosts.eecs.umich.edu/mibench.
10) PolyBench v4.2, datamining/correlation, https://sourceforge.net/projects/polybench/files.
11) sha256sum, Linux user command.
12) Sieve of Erathostenes, codi propi.
13) SpeedTest, Linux speedtest package, https://www.speedtest.net/apps/cli.
14) STREAM GitHub: John D. McCalpin, stream, https://www.cs.virginia.edu/stream/.
15) stress -c UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.
16) stress -m UNIX Tool: R. O. S. Projects, stress, https://github.com/resurrecting-open-source-projects/stress.


METHODOLOGICAL INFORMATION
--------------------------
There are some preliminary steps that must be performed to ensure all programs run correctly:

a. Extending attack duration:
Since the duration of the attacks is too short, a loop has been added to the body of the main function in the attack code to repeat the attack many times. Additionally, the part of the code responsible for generating and writing the result or histogram has been disabled.

b. Enabling performance events:
By default, and for security reasons, most performance counters are disabled — they won’t even appear when running the performance list. This is controlled by a system file called perf_event_paranoid, located in the /proc/sys/kernel/ directory in Linux. There are four available security levels (-1, 0, 1, 2), and setting the file to 0 is sufficient to collect the required data.

c. Cache flushing:
After each program execution, the caches are flushed to prevent them from affecting the behavior of the next run of the same program. This is done by executing the following command before each run: sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"

1. Description of methods used for collection-generation of data: 

To generate the dataset, it is necessary to collect individual data for each program, both benign and malicious. For this purpose, the performance statistics tool **`perf stat`** will be used.

This command-line tool accepts, among other parameters, the different hardware performance counters (HPCs) to be recorded, known as **events** (using the `-e` flag followed by `r0xx`, where `xx` is the hexadecimal number of the hardware event to be monitored). It’s important to note that due to differences between standard event names and what `perf` actually records, it is preferable to follow the hardware manufacturer's documentation.

Other useful parameters include:
- `-C` to specify the CPU to monitor,
- `-D` to set a delay before starting the recording (in milliseconds),
- `-I` to define the sampling interval (in milliseconds).

Additionally, `perf` provides the `-x` flag, which can be followed by a string to format the output in a "table-like" format using the comma character `,`, allowing the result to be saved as a CSV file.

Data from the 20 available counters are collected **one by one**, by repeatedly executing the program.

Finally, a timing tool is used to limit the execution of each program to **30–40 seconds**, since some attacks and reference sets may run indefinitely if not stopped. With a sampling frequency of **10 ms**, this ensures **2,000 samples** per execution. Most attacks, even when repeated, naturally finish in less than 40 seconds. Some records will later be removed to ensure the same number of samples between benign and malicious programs.


2. Methods for processing the data: 

Post-processing was carried out using the awk tool in a Bash script, through which the data from different counters were merged into a single file. The final result consists of 21 columns, representing the timestamp at sample execution time for each of the monitored counter values.

3. Instrument- or software- specific information needed to interpret the data:

Any text editor (open format) or Microsoft Excel (CSV format).

4. Environmental or experimental conditions:

Codes executed on a Xuantie C910 RISC-V core.


5. Quality-assurance procedures performed on the data:

Noise removal in the samples.
Normalization of the data.
Balancing of the collected samples to avoid overfitting in the models.

FILE OVERVIEW
--------------

1. Explain the file naming convention, if applicable:

<program_name>-all_perf_events.csv

2. File List:
File name: bitcoin-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing a code that runs the unit tests of the Bitcoin Core software.

File name: bubble-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing a code that iteratively creates vectors with random elements and sorts them using the bubble-sort algorithm.

File name: bzip2-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the bzip2 program. This program is a high-quality lossless data compressor, which can also be used as a benchmark to provide both computational and memory workloads. To ensure reproducibility, the compressed file will always be the same: a FreeBSD ISO image, as used on the OpenBenchmarking.org website to evaluate bzip2 performance.

File name: coremark-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the CoreMark program, a benchmark designed to test processor characteristics.

File name: dhrystone-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Dhrystone program, a benchmark designed to test processor characteristics.

File name: ffmpeg-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the ffmpeg program. ffmpeg is a multipurpose audio and video tool, which can also be used as a benchmark and as an example of a common mixed workload on a computer. In this example, ffmpeg is used to decompress Big Buck Bunny (https://peach.blender.org/), a large animation created with Blender and widely used for video testing.

File name: mandelbrot-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing a code that sequentially generates the Mandelbrot fractal.

File name: matrix-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing a code that multiplies large quantities of integers to test the CPU’s computational capabilities.

File name: mybench-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the MiBench program, a benchmark specifically designed for the automotive environment. The test performs a bit-counting algorithm that places a significant load on the CPU.

File name: polybench-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Polybench program, a benchmark designed to test processor characteristics by performing various numerical computations.

File name: sha256sum-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the sha256sum command. This program generates a message digest of a file. To ensure reproducibility, the file used will always be the same: a FreeBSD ISO image, specifically the one available at
http://ftp-archive.freebsd.org/pub/FreeBSD-Archive/old-releases/amd64/amd64/ISO-IMAGES/13.0/FreeBSD-13.0-RELEASE-amd64-memstick.img

File name: sieve-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing a code that creates the Sieve of Eratosthenes with a large quantity of numbers.

File name: speedtest-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the SpeedTest program, a benchmark designed to measure the upload and download speed of the internet connection.

File name: stream-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the STREAM program. This program is a benchmark designed to measure memory bandwidth. In this case, it is used exclusively for its effect on stressing the memory unit. The source code is available on the official STREAM website.

File name: stress_c-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the program based on Debian’s stress tool with the -c option. This program subjects the CPU’s computation unit to a stress test by repeatedly calculating square roots of random numbers.

File name: stress_m-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the program based on Debian’s stress tool with the -m option. The -m parameter tests the memory unit by repeatedly executing the malloc() and free() functions.

File name: access-retired-all_perf_events.csv
Description: These data contain the values of the hardware counters analyzed after running the Access Retired program. An attack that monitors retired instructions to detect whether a file is present in a directory that does not allow listing. The proof-of-concept (PoC) code was extracted from CISPA's Github repository.

File name: evict-reload-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Evict+Reload program. This is an attack that detects whether a memory address is in the cache based on the access time after evicting the data. The proof-of-concept (PoC) code was obtained from the CISPA GitHub repository.

File name: fence-flush-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Fence+Flush program. This is an attack that detects whether a memory address is in the cache based on timing differences when flushing the instruction cache. The proof-of-concept (PoC) code was obtained from the CISPA GitHub repository.

File name: flush-fault-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Flush+Fault program. This is an attack that detects whether a memory address is in the cache based on the latency of an exception when jumping to an instruction in the victim’s code. The proof-of-concept (PoC) code was obtained from the CISPA GitHub repository.

File name: flush-fault-ret-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Flush+Fault+ret program. This is an attack that detects whether a memory address is in the cache based on the latency of an exception when jumping to a return instruction in the victim’s code. The proof-of-concept (PoC) code was obtained from the CISPA GitHub repository.

File name: flush-flush-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Flush+Flush program. This is an attack that detects whether the victim has written to a memory address based on timing differences when flushing the instruction cache and accessing it again. The PoC code was obtained from the CISPA GitHub repository.

File name: flush-reload-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Flush+Reload program. This is an attack that detects whether a memory address is in the cache based on timing differences when flushing the cache and accessing it afterward. The PoC code was obtained from the CISPA GitHub repository.

File name: ghostwrite-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the GhostWrite program. This is an attack that resolves the physical address of a virtual address and writes to it directly. The PoC code was obtained from the CISPA GitHub repository.

File name: iflush-reload-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the iFlush+Reload program. This is a variant of the Flush+Reload attack targeting the instruction cache. The PoC code was obtained from the CISPA GitHub repository.

File name: interrupt-timing-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Interrupt Timing program. This is an attack that detects victim interruptions based on the timing differences they cause during code execution. The PoC code was obtained from the CISPA GitHub repository.

File name: page-walk-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Page Walk program. This is an attack that detects page table traversal by counting retired instructions or observing timing differences. The PoC code was obtained from the CISPA GitHub repository.

File name: spectre-rsb-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Spectre RSB program. This is a variation of Spectre that exploits speculation on the Return Stack Buffer (RSB).

File name: spectre-v1-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Spectre version 1 program. The PoC code corresponding to Spectre version 1 was obtained from the CISPA GitHub repository.

File name: spectre-v2-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Spectre version 2 program. The PoC code corresponding to Spectre version 2 was obtained from the GitHub repository.

File name: timer-drift-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the Timer Drift program. This is an attack that monitors retired instructions to detect remote activity. The PoC code was obtained from the CISPA GitHub repository.

File name: tlb-evict-all_perf_events.csv
Description: This data contains the values of the hardware performance counters analyzed after executing the TLB Eviction program. This is an attack that observes timing differences when the victim’s address is in the TLB versus when the TLB is evicted and the address is no longer present. The PoC code was obtained from the CISPA GitHub repository.

3. Relationship between files:

Each file corresponds to one of the 32 programs executed to generate the analyzed hardware performance counter values. Each file is identified by the name of the program associated with its execution.

4. File format:

All the files contain the same variables, so they are only described in the first file.

TABULAR DATA-SPECIFIC INFORMATION
---------------------------------

File name: bitcoin-all_perf_events.csv
Number of rows and columns: 2,677 rows and 21 columns
List of Variables:
Variable name: Time
Description: Sampling time
Units or value labels: ms

Variable name: r002 / Instructions Retired Counter
Description: Hardware counter measuring the number of executed instructions
Units or value labels: Events

Variable name: r003 / L1 ICache Access Counter
Description: Hardware counter measuring the number of accesses to the instruction cache
Units or value labels: Events

Variable name: r004 / L1 ICache Miss Counter
Description: Hardware counter measuring the number of instruction cache misses
Units or value labels: Events

Variable name: r005 / I-UTLB Miss Counter
Description: Hardware counter measuring the number of misses in the instruction User-managed TLB
Units or value labels: Events

Variable name: r006 / D-UTLB Miss Counter
Description: Hardware counter measuring the number of misses in the data User-managed TLB
Units or value labels: Events

Variable name: r007 / JTLB Miss Counter
Description: Hardware counter measuring the number of misses in the Joint TLB
Units or value labels: Events

Variable name: r008 / Conditional Branch Mispredict Counter
Description: Hardware counter measuring the number of conditional branch mispredictions
Units or value labels: Events

Variable name: r009 / Conditional Branch Instruction Counter
Description: Hardware counter measuring the number of executed conditional branches
Units or value labels: Events

Variable name: r00A / Indirect Branch Mispredict Counter
Description: Hardware counter measuring the number of indirect branch mispredictions (e.g., via register)
Units or value labels: Events

Variable name: r00B / Indirect Branch Instruction Counter
Description: Hardware counter measuring the number of executed indirect branches (e.g., via register)
Units or value labels: Events

Variable name: r00C / LSU Spec Fail Counter
Description: Hardware counter measuring the number of failures in the load-store unit, e.g., when a load occurs before a previous store to the same location has completed
Units or value labels: Events

Variable name: r00D / Store Instruction Retired Counter
Description: Hardware counter measuring the number of executed store instructions
Units or value labels: Events

Variable name: r00E / L1 DCache Read Access Counter
Description: Hardware counter measuring the number of read accesses to the level-1 data cache
Units or value labels: Events

Variable name: r00F / L1 DCache Read Miss Counter
Description: Hardware counter measuring the number of read misses in the level-1 data cache
Units or value labels: Events

Variable name: r010 / L1 DCache Write Access Counter
Description: Hardware counter measuring the number of write accesses to the level-1 data cache
Units or value labels: Events

Variable name: r011 / L1 DCache Write Miss Counter
Description: Hardware counter measuring the number of write misses in the level-1 data cache
Units or value labels: Events

Variable name: r012 / L2 Cache Read Access Counter
Description: Hardware counter measuring the number of read accesses to the level-2 cache
Units or value labels: Events

Variable name: r013 / L2 Cache Read Miss Counter
Description: Hardware counter measuring the number of read misses in the level-2 cache
Units or value labels: Events

Variable name: r014 / L2 Cache Write Access Counter
Description: Hardware counter measuring the number of write accesses to the level-2 cache
Units or value labels: Events

Variable name: r015 / L2 Cache Write Miss Counter
Description: Hardware counter measuring the number of write misses in the level-2 cache
Units or value labels: Events

1. File name: bubble-all_perf_events.csv
2. Number of rows and columns: 2,279 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: bzip2-all_perf_events.csv
2. Number of rows and columns: 2,282 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: coremark-all_perf_events.csv
2. Number of rows and columns: 2,291 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: dhrystone-all_perf_events.csv
2. Number of rows and columns: 2,287 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: ffmpeg-all_perf_events.csv
2. Number of rows and columns: 2,054 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: mandelbrot-all_perf_events.csv
2. Number of rows and columns: 2,280 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: matrix-all_perf_events.csv
2. Number of rows and columns: 2,258 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: mybench-all_perf_events.csv
2. Number of rows and columns: 2,271 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: polybench-all_perf_events.csv
2. Number of rows and columns: 2,278 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: sha256sum-all_perf_events.csv
2. Number of rows and columns: 2,399 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: sieve-all_perf_events.csv
2. Number of rows and columns: 2,164 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: speedtest-all_perf_events.csv
2. Number of rows and columns: 2,077 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: stream-all_perf_events.csv
2. Number of rows and columns: 2,300 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: stress_c-all_perf_events.csv
2. Number of rows and columns: 2,300 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: stress_m-all_perf_events.csv
2. Number of rows and columns: 2,231 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: access-retired-all_perf_events.csv
2. Number of rows and columns: 2,862 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: evict-reload-all_perf_events.csv
2. Number of rows and columns: 2,200 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: fence-flush-all_perf_events.csv
2. Number of rows and columns: 2,182 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: flush-fault-all_perf_events.csv
2. Number of rows and columns: 2,856 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: flush-fault-ret-all_perf_events.csv
2. Number of rows and columns: 2,854 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: flush-flush-all_perf_events.csv
2. Number of rows and columns: 2,213 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: flush-reload-all_perf_events.csv
2. Number of rows and columns: 2,279 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: ghostwrite-all_perf_events.csv
2. Number of rows and columns: 2,286 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: iflush-reload-all_perf_events.csv
2. Number of rows and columns: 3,070 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: interrupt-timing-all_perf_events.csv
2. Number of rows and columns: 3,022 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: page-walk-all_perf_events.csv
2. Number of rows and columns: 3,087 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: spectre-rsb-all_perf_events.csv
2. Number of rows and columns: 3,054 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: spectre-v1-all_perf_events.csv
2. Number of rows and columns: 2,285 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: spectre-v2-all_perf_events.csv
2. Number of rows and columns: 3,055 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: timer-drift-all_perf_events.csv
2. Number of rows and columns: 3,861 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.

1. File name: tlb-evict-all_perf_events.csv
2. Number of rows and columns: 3,012 rows and 21 columns
3. List of Variables: Contains the same variables as described for the first file.